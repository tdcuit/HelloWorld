package test.domain;

public class Statistic {
    private Long advertiseNum;

    private Long userNum;

    private Long productNum;

    public Long getAdvertiseNum() {
        return advertiseNum;
    }

    public void setAdvertiseNum(Long advertiseNum) {
        this.advertiseNum = advertiseNum;
    }

    public Long getUserNum() {
        return userNum;
    }

    public void setUserNum(Long userNum) {
        this.userNum = userNum;
    }

    public Long getProductNum() {
        return productNum;
    }

    public void setProductNum(Long productNum) {
        this.productNum = productNum;
    }
}